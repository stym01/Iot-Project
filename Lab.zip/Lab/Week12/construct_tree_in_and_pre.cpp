#include<iostream>
#include<vector>
using namespace std;

struct TreeNode{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x)
    {
        val = x;
        left = NULL;
        right = NULL;
    }
};

TreeNode* tree(vector<int>& preorder,vector<int>& inorder,int pstart,int pend,int istart,int iend){
    if(istart>iend){
        return nullptr;
    }
    TreeNode* root = new TreeNode(preorder[pstart]);
    int index=istart;
    while(inorder[index]!=root->val){
        index++;
    }
    root->left=tree(preorder,inorder,pstart+1,index-istart+pstart,istart,index-1);
    root->right=tree(preorder,inorder,index-istart+pstart+1,pend,index+1,iend);
    return root;
}

TreeNode* buildTree(vector<int>& preorder, vector<int>& inorder) {
    return tree(preorder,inorder,0,preorder.size()-1,0,inorder.size()-1);
}


void postorder(TreeNode* root)
{
    if (!root) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->val << " ";
}

bool checkinorder(vector<int> &inorder , TreeNode* root , int &index)
{
    if(!root) return true;
    if(!checkinorder(inorder , root->left , index)) return false;
    if(root->val != inorder[index]) return false;
    index++;
    if(!checkinorder(inorder , root->right , index)) return false;
    return true;
}

bool checkpreorder(vector<int> &preorder , TreeNode* root , int &index)
{
    if(!root) return true;
    if(root->val != preorder[index]) return false;
    index++;
    if(!checkpreorder(preorder , root->left , index)) return false;
    if(!checkpreorder(preorder , root->right , index)) return false;
    return true;
}

bool check(vector<int> & inorder, vector<int> &preorder , TreeNode* root)
{
    int i = 0, j = 0;
    bool temp1 = checkinorder(inorder , root , i);
    bool temp2 = checkpreorder(preorder , root , j);

    if(temp1 && temp2)
    {
        postorder(root);
        return true;
    }
    else return false;
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        int n;  
        cin >> n;
        vector<int> preorder(n);
        vector<int> inorder(n);

        for(int i=0;i<n;i++) cin >> preorder[i];
        for(int i=0;i<n;i++) cin >> inorder[i];

        TreeNode* root = buildTree(preorder , inorder);
        bool ans = check(inorder , preorder, root);
        if(!ans) cout << "Wrong" ;

        cout << endl;
    }
    return 0;
}

/*
Test Cases:
11

7
1 2 4 5 3 6 7
4 2 5 1 6 3 7

9
10 5 3 7 20 15 12 25 30
3 5 7 10 12 15 20 25 30

15
1 2 4 8 9 5 10 11 3 6 12 13 7 14 15
8 4 9 2 10 5 11 1 12 6 13 3 14 7 15

6
10 9 8 7 6 5
5 6 7 8 9 10

6
1 2 3 4 5 6
1 2 3 4 5 6

6
10 9 8 7 6 5
9 7 8 5 6 10

6
1 2 3 4 5 6
6 5 4 3 2 1

6
1 2 3 4 5 6
1 2 3 4 5 6

7
1 2 4 5 6 7 8
1 2 4 5 6 7 8

7
8 7 6 5 4 2 1
1 2 4 5 6 7 8

1
99
99


Output :
4 5 2 6 7 3 1
3 7 5 12 15 30 25 20 10  Random Tree
8 9 4 10 11 5 2 12 13 6 14 15 7 3 1 full bt
5 6 7 8 9 10 left 
6 5 4 3 2 1 right
7 5 6 8 9 10 zig zag
6 5 4 3 2 1 Root with Deep Left Subtree
6 5 4 3 2 1 Root with Deep right Subtree
8 7 6 5 4 2 1 rigth subtree
1 2 4 5 6 7 8 left subtree
99 Only Root 

*/