#include<iostream>
#include<vector>
using namespace std;

int insertNintoM(int n ,int m ,int i, int j)
{
    int allOnes = ~0;

    int left = allOnes << (j + 1);
    if(left <0)
    {
        left = 0;
    }
    int right = (1 << i) - 1;

    int mask = left | right;

    m = m & mask;

    n = n << i;

    int ans = m | n;
    return ans;
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        int m , n;
        cin >> m >> n;
        int i , j;
        cin >>i >>j;

        int ans = insertNintoM(n,m,i,j);

        cout << ans << endl;
    }
    return 0;
}

/*
Test Cases:

7
16384 19 2 6 
16388 19 2 6 
16388 19 0 4
16403 19 0 4
16384 1 0 0
511 5 6 8
35 78 0 31

Output :
16460
16460
16403
16403
16385
383
78

*/