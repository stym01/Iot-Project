#include<iostream>
#include<vector>
using namespace std;

pair<int,int> findXandY(vector<int> arr , int n)
{
    int totalXor = 0;
    for(int i=0;i<n+2;i++) totalXor ^= arr[i];
    for(int i=0;i<n;i++) totalXor ^= (i+1);

    int pos = 0;
    
    pos = totalXor & (-totalXor);//will give rightmost set bit

    int x = 0, y = 0;
    for (int num : arr)
    {
        if (num&pos)
            x ^= num;
        else
            y ^= num;
    }
    for (int i=1;i<=n;i++)
    {
        if (i&pos)
            x ^= i;
        else
            y ^= i;
    }

    return {x,y};
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        int n;
        cin >> n;

        if(n <2) 
        {
            cout << -1 << endl;
            cout << endl;
            continue;
        }
        vector<int> arr(n+2,0);
        for(int i=0;i<n+2;i++) cin >> arr[i];

        pair<int,int> res = findXandY(arr , n);
        cout << res.first << " "<< res.second << endl;
        cout << endl;
    }
    return 0;
}


/*

test Cases

Input:
10
7
1 4 5 2 3 6 7 2 3
8
6 3 2 4 1 5 8 7 6 2
7
1 5 6 3 4 2 6 3 7
6
3 6 5 2 4 1 5 3 
8
2 5 3 6 8 7 4 1 1 2
7
6 5 3 1 4 2 7 6 7
8
2 6 1 1 3 4 7 8 8 5
2
1 2 1 2
0
1


Ouptur:

2 3
6 2
3 6
5 3
1 2
6 7
1 8
1 2
-1 -1
-1 -1

*/