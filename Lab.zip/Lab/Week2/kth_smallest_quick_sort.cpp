#include <iostream>
#include <vector>
using namespace std;

int Partition(vector<int>& arr, int p, int r) {
    int pivot = arr[p];
    int j = r + 1;
    for (int i = r; i > p; i--) {
        if (arr[i] < pivot) {
            j--;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[p], arr[j - 1]);
    return j - 1;
}

int QuickSort(vector<int>& arr, int p, int r, int k) {
    int q = Partition(arr, p, r);
    if (q == k - 1)
        return arr[q];
    else if (q >= k)
        return QuickSort(arr, p, q - 1, k);
    else
        return QuickSort(arr, q + 1, r, k);
}

int findKthLargest(vector<int>& arr, int k) {
    int n = arr.size();
    return QuickSort(arr, 0, n - 1, k);
}

// Driver code for testing
int main() {
    vector<int> arr = {3, 2, 1, 5, 6, 4};
    int k = 2;
    cout << "The " << k << "th largest element is: " << findKthLargest(arr, k) << endl;
    return 0;
}
