#include <bits/stdc++.h>
using namespace std;

int kthSmallest(vector<int> &arr, int n, int k) {
    priority_queue<int, vector<int>, greater<int>> pq(arr.begin(), arr.end());

    for (int i = 1; i < k; i++)
    {
        pq.pop();
    }
    return pq.top();
}

int main() {
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        vector<int> arr(n);
        for (int i = 0; i < n; i++) cin >> arr[i];

        cout << kthSmallest(arr, n, k) << endl;
    }
    return 0;
}
/*

Assume:
no negative and k never greater than n

Test cases:

8
5 3
7 10 4 3 201
6 1
8 5 12 7 9 3
6 6
8 5 12 7 9 3
5 3
0 0 0 0 0
7 4
1 2 3 4 5 6 7
7 2
10 9 8 7 6 5 4
7 4
5 3 3 2 4 4 1
1 1
42

output:

*/
