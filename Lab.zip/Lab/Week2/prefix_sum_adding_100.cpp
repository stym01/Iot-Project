#include<bits/stdc++.h>
using namespace std;

/*
Problem Description:
You are given an array of size `n`, initialized with all zeros. You need to perform `m` operations,
where each operation specifies a range `[a, b]` (0-based indexing). For each operation:
Increment all elements in the range `[a, b]` by 100.
*/

int maxElem(vector<int> count, int n,int m) {

    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;

        

        if (a >= 0 && a < n && b >= a && b < n) {
            count[a] += 1;
            count[b + 1] -= 1;
        }
    }

    for (int i = 1; i < n; i++) {
        count[i] = count[i] + count[i - 1];
    }

    int maxi = 0;
    for (int i = 0; i < n; i++) {
        maxi = max(maxi, count[i]);
    }

    return maxi * 100;
}

int main() {
    int t;
    cin >>t;
    while(t -- )
    {
        int n, m;
        cin >> n >> m;

        if(n == 0 || m == 0) 
        {
            cout << -1 << endl;
            continue;
        }

        vector<int> count(n, 0);

        int ans = maxElem(count, n,m);
        cout << ans << endl;
    } 
    return 0;
}

// a is always smaller than b
// if n = 0 and m = 0 then returns -1

/*

Input :
6
5
4
0 3
1 2
0 1
0 4
5
4
0 0
0 2
1 1
1 4
5 
4
2 4
4 2
1 3
1 2
4
5
0 6
1 3
2 4
1 5
2 2
1
2
0 0
0 1
0
1

Output :
400
300
300
200
100
-1

*/