#include<iostream>
#include<vector>
using namespace std;

// Given an array arr[], the task is to find the subarray that has the maximum sum and return its sum.

int largestSubarraySum(vector<int> arr, int n)
{
    int max_upto_i = 0;
    int best = INT_MIN;
    for (int i = 0; i < n; i++)
    {
        max_upto_i += arr[i];
        if (max_upto_i >= best)
        {
            best = max_upto_i;
        }
        if (max_upto_i < 0) max_upto_i = 0;
    }
    return best;
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;

        // handling 0 size testcase
        if(n == 0)
        {
            cout << -1 << endl;
            continue;
        }

        vector<int> arr(n);
        
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
        }

        int ans = largestSubarraySum(arr, n);
        cout << ans << endl;
    }
    return 0;
}

/*
Test Cases 
7
7
2 3 -8 7 -1 2 3
7
6 -2 -8 -6 -1 0 -3
7
-8 -6 -1 0 -3 -1 18
8
-9 -5 -6 -3 -1 -2 -4 -7 
6
1 2 -4 5 6 -3
6
0 0 0 0 0 0
1
48

Result
11
6
18
-1
11
0
48

*/