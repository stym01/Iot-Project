#include<iostream>
#include<vector>
#include<queue>
using namespace std;

void bfs(vector<vector<int>> & grid , vector<vector<int>> & vis , int x , int y , queue<pair<int,int>> & q ,int n ,int m , vector<vector<pair<int,int>>> & path)
{
    q.push({x,y});
    vector<pair<int,int>> temp;
    temp.push_back({x,y});
    while(!q.empty())
    {
        int x = q.front().first;
        int y = q.front().second;
        q.pop();
        vis[x][y] = 1;
        int dir[8][2] = {{-1,0},{-1,-1},{-1,1},{0,1},{0,-1},{1,-1},{1,0},{1,1}};

        for(int i=0;i<8;i++)
        {
            int newx = x + dir[i][0];
            int newy = y + dir[i][1];
            if(newx<n && newy<m && newx>=0 && newy>=0 && vis[newx][newy] == 0 && grid[newx][newy] == 1)
            {
                q.push({newx,newy});
                vis[newx][newy] = 1;
                temp.push_back({newx , newy});
            }
        }
    }
    path.push_back(temp);
}

int countIslands(vector<vector<int>> & grid , int n ,int m ,vector<vector<pair<int,int>>> & path)
{
    queue<pair<int,int>> q;
    vector<vector<int>> vis(n , vector<int> (m , 0));
    int cnt = 0;
    
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(!vis[i][j] && grid[i][j] == 1)
            {
                bfs(grid , vis , i , j ,q , n ,m , path);
                cnt++;
            }
        }
    }

    return cnt;
}

void printPaths(vector<vector<pair<int,int>>> & path)
{
    for(int i=0;i<path.size();i++)
    {
        for(int j=0;j<path[i].size();j++)
        {
            cout << '{' << path[i][j].first << ',' << path[i][j].second << '}' ;
        }
        cout << endl;
    }
    cout << endl;
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        int n;
        cin >> n;
        int m;
        cin >>m;
        vector<vector<int>> grid(n , vector<int> (m));
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                cin >> grid[i][j];
            }
        }

        vector<vector<pair<int,int>>> path;

        int noOfIsland = countIslands(grid, n , m , path);
        cout << noOfIsland << endl;
        cout << endl;
        printPaths(path);

    }
}

/*
Test Cases 

4 4
1 0 1 1
1 0 0 1
0 1 0 0
0 0 1 0

4 4
1 0 1 0
0 1 0 1
1 0 1 0
0 1 0 1

4 5
1 0 1 0 1
1 0 1 0 1
1 0 1 0 1
1 0 1 0 1

5 1
1
0
0
1
1

1 6
1 0 0 0 0





Output
2
1
3
2
1

*/