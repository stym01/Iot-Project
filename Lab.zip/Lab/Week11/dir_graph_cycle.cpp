#include<iostream>
#include<vector>
#include<queue>
using namespace std;

void input(vector<vector<int>> & graph)
{
    int edges;
    cin >> edges;
    for(int i=0;i<edges;i++)
    {
        int u,v;
        cin>>u>>v;
        graph[u-1].push_back(v-1);
    }
}

bool cyclePresenceTopo(vector<vector<int>> & graph , int v)
{
    vector<int> indegree(v , 0);
    for (int i = 0; i < v; i++) {
        for (auto it : graph[i]) {
            indegree[it]++;
        }
    }

    queue<int> q;
    for (int i = 0; i < v; i++) {
        if (indegree[i] == 0) {
            q.push(i);
        }
    }

    int cnt = 0;
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        cnt++;

        for (auto it : graph[node]) {
            indegree[it]--;
            if (indegree[it] == 0) {
                q.push(it);
            }
        }
    }

    return cnt != v;
}

// bool cyclePresenceBFS(vector<vector<int>>& graph , int v)
// {
//     vector<bool> visited(v, false);
//     vector<bool> pathVisited(v, false);
    
//     for (int i = 0; i < v; i++)
//     {
//         if (!visited[i])  // Start BFS for each unvisited node
//         {
//             queue<int> q;
//             q.push(i);
//             pathVisited[i] = true;
//             visited[i] = true;

//             while (!q.empty())
//             {
//                 int node = q.front();
//                 q.pop();
//                 pathVisited[node] = false;  // Remove from path visited after processing

//                 for (auto it : graph[node])
//                 {
//                     if (!visited[it])
//                     {
//                         q.push(it);
//                         visited[it] = true;
//                         pathVisited[it] = true;
//                     }
//                     else if (pathVisited[it]) // Cycle detected
//                     {
//                         return true;
//                     }
//                 }
//             }
//         }
//     }
//     return false;
// }

bool dfsHelp(vector<vector<int>>& graph , int x , vector<bool> &vis , vector<bool> & pathvis)
{
    vis[x] = true;
    pathvis[x] = true;
    for(auto it : graph[x])
    {
        if(!vis[it])
        {
            if(dfsHelp(graph , it , vis , pathvis )) return true;
        }
        else if(pathvis[it])
        {
            return true;
        }
    }
    pathvis[x] = false;
    return false;
}

bool cyclePresenceDFS(vector<vector<int>>& graph , int v)
{
    vector<bool> vis(v,false);
    vector<bool> pathvis(v,false);
    
    for(int i=0;i<v;i++)
    {
        if(!vis[i])
        {
            if(dfsHelp(graph , i , vis ,pathvis )) return true;
        }
    }
    return false;
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int v;
        cin >>v;
        vector<vector<int>> graph(v);
        input(graph);

        bool isCyclicTopo = cyclePresenceTopo(graph , v);
        cout << isCyclicTopo << endl;
        
        bool isCyclicDFS = cyclePresenceDFS(graph , v);
        cout << isCyclicDFS << endl;

        // bool isCyclicBFS = cyclePresenceBFS(graph , v);
        // cout << isCyclicBFS << endl;
        cout << endl;
    }
}