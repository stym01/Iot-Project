#include<iostream>
#include<unordered_map>
using namespace std;

struct Node
{
    int val;
    Node* next;
    Node* random;

    Node(int x)
    {
        val = x;
        next = NULL;
        random = NULL;
    }
};

Node* createLL()
{
    Node* tail = NULL;
    Node* head = NULL;

    vector<Node*> mp;
    int n;
    cin >>n;
    int newN = n;

    while(n--)
    {
        int x;
        cin >> x;

        Node* temp = new Node(x);

        mp.push_back(temp);
        if(head == NULL)
        {
            head = temp;
            tail = temp;
        }
        else
        {
            tail->next = temp;
            tail = temp;
        }
    }
    tail->next = NULL;

    Node* temp = head;
    while(temp != NULL)
    {
        int y;
        cin >>y;

        if(y < newN && y >= 0)
        {
            temp->random = mp[y];
            temp = temp->next;
        }
        else
        {
            temp->random = NULL;
            temp = temp->next;
        }
    }
    return head;
}

void printLL(Node* temp)
{
    while(temp != NULL)
    {
        cout << temp->val << " " << temp->random->val;
        temp = temp -> next;
    }
}

Node* cloneLL(Node* head)
{
    if (!head) return nullptr;

    unordered_map<Node*, Node*> nodeMap;

    // First traversal: Create copy of each node and store mapping
    Node* curr = head;
    while (curr) {
        nodeMap[curr] = new Node(curr->val);
        curr = curr->next;
    }

    // Second traversal: Set next and random pointers using the map
    curr = head;
    while (curr) {
        nodeMap[curr]->next = nodeMap[curr->next];
        nodeMap[curr]->random = nodeMap[curr->random];
        curr = curr->next;
    }

    return nodeMap[head];
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        Node* root = createLL();

        Node* ans = cloneLL(root);

        printLL(root);
        printLL(ans);
    }
    return 0;

}