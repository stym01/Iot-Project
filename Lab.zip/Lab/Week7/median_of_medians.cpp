#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int partition(vector<int> &arr , int p, int r , int median)
{
    int i = p - 1;
    for (int j = p; j < r; j++)
    {
        if (arr[j] < median)
        {
            i++;
            swap(arr[i] , arr[j]);
        }
        else if (arr[j] == median)
        {
            swap(arr[j] , arr[r]);
            j--;
        }
    }
    i++;
    int temp = arr[i];
    arr[i] = arr[r];
    arr[r] = temp;
    return i;
}

int momHelper(vector<int>& arr , int p , int r , int k)
{
    if(arr.size() == 1)
    {
        return arr[0];
    }
    vector<int> temp;

    for(int i=p;i<=r;i+=5)
    {
        if(i+5 < arr.size())
        {
            sort(arr.begin()+i , arr.begin()+i+5);
        }
        else
        {
            sort(arr.begin()+i , arr.end());
        }

        int median = (i + min(i+5,r))/2;
        temp.push_back(arr[median]);
    }
    return momHelper(temp , 0 , temp.size()-1 , k);
}

int medianOfMedians(vector<int>& arr , int p , int r , int k)
{
    if(p <= r)
    {
        int median = momHelper(arr , p , r , k);
        int q = partition(arr, p , r , median);

        if(q == k-1) 
        {
            return arr[q];
        }
        if(q > k-1)
        {
            return medianOfMedians(arr , p , q-1 , k);
        }
        else
        {
            return medianOfMedians(arr , q+1 , r , k);
        }
    }
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        int n;
        cin >>n;

        vector<int> arr(n,0);
        for(int i=0;i<n;i++)
        {
            cin >>arr[i];
        }
        
        int k;
        cin >>k;

        int mom = medianOfMedians(arr,0,n-1,k);

        cout << mom << endl;
        cout << endl;
    }
    return 0;
}

/*

Test Case

1
7
6 3 2 8 7 9 1
6



Output:



*/