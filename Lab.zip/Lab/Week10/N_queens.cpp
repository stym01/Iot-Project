#include <iostream>
using namespace std;

int x[100];

void nextValue(int k, int n)
{
    while(1)
    {
        x[k] = (x[k] + 1) % (n + 1); 
        if (x[k] == 0) return;  
        int j;
        for (j = 1; j < k; j++)   
        {
            if (x[j] == x[k] || abs(x[j] - x[k]) == abs(j - k) )
            {
                break;
            }
        }
        if (j == k) return;
    }
}

void nqueen(int k, int n)
{
    while (1)
    {
        nextValue(k, n);
        if (x[k] == 0) return;
        if (k == n)
        {
            for (int i = 1; i <= n; i++)
            {
                cout << x[i] << " ";  
            }
            cout << endl;
        }
        else 
        {
            nqueen(k + 1, n);
        }
    }
}

int main()
{
    int t;
    cin >>t ;
    while (t--)
    {
        int n;
        cin >>n;
        for (int i = 0; i < 100; i++)
        {
            x[i] = 0;
        }
        nqueen(1, n);
    }
    return 0;
}