#include<iostream>
#include<vector>
using namespace std;

int i=0;
vector<int>index;

int parent(int i) {return (i-1)/2;}
int left(int i) {return i*2+1;}
int right(int i) {return i*2+2;}
int heapsize;

void heapify(int i,vector<pair<int,int>>&arr){
    int smallest=i;
    if(left(i)<=heapsize && arr[left(i)].first<arr[smallest].first){
        smallest=left(i);
    }
    if(right(i)<=heapsize && arr[right(i)].first<arr[smallest].first){
        smallest=right(i);
    }
    if(smallest!=i) {
        swap(index[arr[smallest].second],index[arr[i].second]);
        swap(arr[smallest],arr[i]);
        heapify(smallest,arr);
    }
}

pair<int,int> extractMin(vector<pair<int,int>>&arr){
    pair<int,int>mini=arr[0];
    index[arr[0].second]=-1;
    swap(index[arr[0].second],index[arr[heapsize].second]);
    swap(arr[0],arr[heapsize]);
    index[arr[0].second]=0;    
    heapsize--;
    heapify(0,arr);
    return mini;
}

void decreaseKey(int i,int key,vector<pair<int,int>>&arr){
    if(i>heapsize) return;
    if(key>=arr[i].first) return;
    arr[i].first=key;
    while(i>0 && arr[i].first<arr[parent(i)].first){
        swap(index[arr[i].second],index[arr[parent(i)].second]);
        swap(arr[i],arr[parent(i)]);
        i=parent(i);
    }
}

void insert(pair<int,int> x,vector<pair<int,int>>&arr){
    heapsize++;
    arr[heapsize].second=x.second;
    index[x.second]=heapsize;
    decreaseKey(heapsize,x.first,arr);
}


int spanningTree(int V, vector<vector<pair<int,int>>>&adj) {
    heapsize=V-1;
    index.resize(V);
    for(int i=0;i<V;i++){
        index[i]=i;
    }

    vector<pair<int,int>>arr(V);
    for(int i=0;i<V;i++){
        arr[i].first=1e9;
        arr[i].second=i;
    }
    decreaseKey(0,0,arr);
    vector<int>vis(V,0);

    int sum=0;
    while(heapsize>=0){
        pair<int,int>temp=extractMin(arr);
        int wt=temp.first;
        int node=temp.second;
        // if (vis[node]) continue;

        vis[node]=1;
        sum+=wt;

        for(auto it:adj[node]){
            int adjNode=it.first;
            int weight=it.second;
            if(vis[adjNode]==0){
                    decreaseKey(index[adjNode],weight,arr);
            }
        }
    }
    return sum;
}

void solve(int V,vector<pair<int,pair<int,int>>>&edges){
    vector<vector<pair<int,int>>>adj(V);
    for(auto it:edges){
        int wt=it.first;
        int node=it.second.first;
        int adjNode=it.second.second;
        adj[node].push_back({adjNode,wt});
        adj[adjNode].push_back({node,wt});
    }
    int sum=spanningTree(V,adj);
    cout<<"Sum is : "<<sum<<endl;
    cout<<endl;
}

int main(){
    
    freopen("MST.txt", "r", stdin); 
    freopen("output.txt", "w", stdout); 

    int t;
    cin>>t;
    while(t--){
        int V,E;
        cin>>V>>E;
        vector<pair<int,pair<int,int>>>edges;
        for(int i=0;i<E;i++){
            int node,adjNode,wt;
            cin>>node>>adjNode>>wt;
            edges.push_back({wt,{node,adjNode}});
        }
        solve(V,edges);
    }

}

