// given an positive integer n print the nwt smallest number having same number of 1s in the binary representationsol
// 1.use bit vector
// 2.without using bit vector 
// implement file operation compare output1.txt with output2.txt 

#include<iostream>
#include<vector>
using namespace std;

void assign(int n,vector<bool>& bits){
    for(int i=0;i<32;i++){
        int val=n&(int(pow(2,31-i)));
        if(val){
            bits[i]=true;
        }
    }
}
int solve(int n){
    vector<bool>bits(32,false);
    assign(n,bits);
    int i=31;
    for(i=31;i>0;i--){
        if(bits[i] && !bits[i-1]){
            swap(bits[i],bits[i-1]);
            break;
        }
    }
    i++;
    int j=31;
    while(i<j){
        while(bits[j]){
            j--;
        }
        if(i>=j){
            break;
        }
        if(bits[i]==1){
            swap(bits[i],bits[j]);
            i++;
            j--;
        }
        else{
            break;
        }
    }
    int ans=0;
    for(int i=0;i<32;i++){
        bool val=bits[i];
        if(val){
            ans+=int(pow(2,31-i));
        }
    }
    return ans;
}

int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int ans=solve(n);
        cout<<ans<<endl;
    }
}