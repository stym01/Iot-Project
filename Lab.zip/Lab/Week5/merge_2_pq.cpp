#include <iostream>
#include <vector>

using namespace std;

void maxHeapify(vector<int> &heap, int i, int size)
{
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < size && heap[left] > heap[largest])
        largest = left;

    if (right < size && heap[right] > heap[largest])
        largest = right;

    if (largest != i)
    {
        swap(heap[i], heap[largest]);
        maxHeapify(heap, largest, size);
    }
}

void buildHeap(vector<int> &arr, int size) 
{
    for (int i = (size / 2) - 1; i >= 0; i--)
    {
        maxHeapify(arr, i, size);
    }
}

void mergeHeaps(vector<int> &A, vector<int> &B, int m, int n)
{
    for (int i = 0; i < n; i++)
    {
        A[m + i] = B[i];
    }
    buildHeap(A, m + n);
}

int main() {
    int t;
    cin >> t;
    
    while (t--)
    {
        int m, n;
        cin >> m >> n;

        vector<int> A(m + n);
        vector<int> B(n);

        for (int i = 0; i < m; i++) cin >> A[i];
        for (int i = 0; i < n; i++) cin >> B[i];

        buildHeap(A ,m);
        buildHeap(B ,n);

        mergeHeaps(A, B, m, n);

        for (int i = 0; i < m + n; i++) {
            cout << A[i] << " ";
        }
        cout << endl;
    }
    return 0;
}
/*
Input Format


Test Cases
Input
8
4 6
4 2 8 1
6 10 9 3 0 5

6 5
1 2 3 4 5 6
1 2 3 4 5

7 5
10 9 7 5 3 2 1
9 5 2 1 0

3 4
1 1 1
1 1 1 1

1 1
1000
3

0 6

6 10 39 2 68 5

7 9
1 3 5 7 9 13 11
2 4 6 8 10 12 15 16 17

5 8
1 5 8 2 6
10 12 9 38 20 21 45 29




Output
10 8 9 3 5 6 4 1 0 2
6 5 5 4 2 1 3 4 3 1 2
10 9 7 9 3 2 1 5 5 2 1 0
1 1 1 1 1 1 1
1000 3
68 10 39 2 6 5
17 16 12 13 15 11 6 7 9 3 8 10 5 1 4 2
45 29 38 21 20 12 8 6 2 5 10 9 1
*/