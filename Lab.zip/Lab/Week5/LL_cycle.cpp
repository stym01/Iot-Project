#include<iostream>
#include<unordered_map>
using namespace std;

struct Node {
    int val;
    Node* next;
    Node(int x) : val(x), next(NULL) {}
};

Node* createLL(int n)
{
    Node * head = NULL;
    Node * tail = NULL;
    int cyclePosition;
    cin >> cyclePosition;

    Node* temp = NULL;

    while(n)
    {
        int val;
        cin >> val;
        Node *newNode = new Node(val);
        if(head == NULL)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }

        cyclePosition--;
        if(cyclePosition == 0)
        {
            temp = tail;
        }
        n--;
    }

    tail->next = temp;
    return head;
}

bool isCyclic(Node * head)
{
    Node* hare = head;
    Node* tortoise = head;

    while(hare != NULL && hare->next != NULL)
    {
        hare = hare->next->next;
        tortoise = tortoise->next;
        if(hare == tortoise) return true;
    }
    return false;
}

void printLinkedList(Node* head)
{
    while (head) {
        cout << head->val << " ";
        head = head->next;
    }
    cout << endl;
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        int n;
        cin >>n;

        Node* root = createLL(n);

        bool cyclePresent = isCyclic(root);

        cout << cyclePresent << endl;
    }
    return 0;
}

// Assuming that whenever the user wants to end the list he can send the value -1
// Assuming that in case of no value in LL then assume it to be not cyclic.
// self loop not exist

/*

Test Cases

Input 
11
10
4
1 2 3 4 5 8 5 2 6 9
7
3
5 6 2 1 9 78 8
9
3
5 2 7 8 6 3 0 4 3
9
4
2 9 86 2 4 8 52 30 5
8
5
6 2 8 9 62 5 7 10 
8
6
0 93 1 8 5 3 2 8
8
-1
3 9 2 0 7 52 9 63
7
7
2 0 5 9 87 6 4 
2
0
2 6 
2
-1
8 4 
1
-1
5



output
1
1
1
1
1
1
0
1
1
0
0

*/