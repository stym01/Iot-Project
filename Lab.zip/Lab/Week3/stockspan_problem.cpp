#include<bits/stdc++.h> 
using namespace std;

vector<int> stockspan(int n , vector<int> arr)
{
    vector<int> res(n,0);
    stack<int> st;
    for(int i=0;i<n;i++)
    {
        while(!st.empty() && arr[i] >= arr[st.top()])
        {
            st.pop();
        }
        if(st.empty()) res[i] = i+1;
        else res[i] = i - st.top();
        st.push(i);
    }
    if(res.size() == 0) cout << -1 ;
    return res;
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        int n;
        cin >>n;
        vector<int> arr(n,0);
        for(int i=0;i<n;i++) cin >> arr[i];

        vector<int> span(n,0);
        span = stockspan(n,arr);
        for(int i=0;i<n;i++)
        {
            cout << span[i] << " " ;
        }
        cout << endl;
    }
    return 0;
}


// assumption 
// in case of n =0 code will print nothing
/* test cases

9
7
100 80 85 70 60 75 90
5
100 100 100 100 100
6
20 30 40 50 60 70
6
100 90 80 60 50 40
0
1
200
2
30 60
10
30 50 60 10 90 110 60 50 20 120
5
0 0 0 0 0

Output :
1 1 2 1 1 3 6
1 2 3 4 5
1 2 3 4 5 6
1 1 1 1 1 1
-1
1
1 2
1 2 3 1 5 6 1 1 1 10
1 2 3 4 5

*/