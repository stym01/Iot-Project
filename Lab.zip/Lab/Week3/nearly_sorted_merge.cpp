#include<bits/stdc++.h>
using namespace std;

void merge(int p,int q,int r, vector<int> & arr){
    int n1=q-p+1;
    int n2=r-q;
    vector<int>l(n1+1);
    vector<int>b(n2+1);

    for(int i=0;i<n1;i++){
      l[i]=arr[p+i];
    }
    for(int i=0;i<n2;i++){
        b[i]=arr[q+1+i];
    }
    l[n1]=INT_MAX;
    b[n2]=INT_MAX;
    int i=0;
    int j=0;
    for(int k=p;k<=r;k++){
        if(l[i]<=b[j]){
            arr[k]=l[i];
            i=i+1;
        }
        else{
            arr[k]=b[j];
            j=j+1; 
        }
    }
}

void mergesort(int p,int r,vector<int> & arr){
    if(p<r){
        int q=(p+r)/2;
        mergesort(p,q,arr);
        mergesort(q+1,r,arr);
        merge(p,q,r,arr);
    }
}

void sort(int n,int k, vector<int> &arr){
    int start=0;
    while(start<n){
        int end=min(start+2*k-1,n-1);
        mergesort(start,end,arr);
        start+=k;
    }
}

int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int k;
        cin>>k;
        vector<int>arr(n);
        for(int i=0;i<n;i++){
            cin>>arr[i];
        }
        sort(n,k,arr);
        for(int i=0;i<n;i++){
            cout<<arr[i]<<" ";
        }
        cout<<endl;
    }
}


/*

test cases :
8
4 2
2 1 4 3
6 3
3 4 5 1 2 6
7 3
3 1 4 10000 600 200000000 30
6 4
1 2 3 4 5 6
5 3
2 2 2 2 2
6 6
8 7 9 3 2 1
6 0
2 3 5 6 8 9
0 3


Output:
1 2 3 4
1 2 3 4 5 6
1 3 4 30 600 10000 200000000
1 2 3 4 5 6
2 2 2 2 2
1 2 3 7 8 9
2 3 5 6 8 9
-1


*/