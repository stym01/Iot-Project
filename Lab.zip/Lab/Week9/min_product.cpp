#include<bits/stdc++.h>
using namespace std;

int finMinProduct(vector<int> &arr ,int n)
{
    int finalAns = 0;
    int mini = INT_MAX;
    int negCount = 0;
    int elementNearestToZero = INT_MIN;
    int prodWithoutZero = 1;

    for(int i=0;i<n;i++)
    {
        mini = min(mini , arr[i]);
        if(arr[i] < 0) negCount++;
        if(arr[i] != 0) prodWithoutZero *= arr[i];
        if(arr[i] < 0 ) elementNearestToZero = max(elementNearestToZero , arr[i]);
    }

    if(negCount == 0) finalAns = mini;
    else if(negCount % 2 == 0) finalAns = prodWithoutZero/elementNearestToZero;
    else if(negCount % 2 == 1) finalAns = prodWithoutZero;

    return finalAns;
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;
        vector<int> arr(n);
        for(int i=0;i<n;i++) cin >> arr[i];

        int min_product_of_subarray = finMinProduct(arr, n);
        cout << min_product_of_subarray << endl;
        cout << endl;
    }
    return 0;
}


/*
Test Cases:

10
4
1 2 3 4

5
0 5 69 8 7

4
-2 1 8 6 

5
-4 6 9 0 5 

5
-6 -7 0 5 6 

6
-5 -9 -6 -7 -3 -1

5
-5 -9 -8 -6 -2

1
2

1
0

1
-3

Output:
1
0
-96
-1080
-210
-5670
-4320
2
0
-3

*/