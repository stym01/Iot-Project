#include <bits/stdc++.h>
using namespace std;

struct Node {
    int freq;
    string name;
    Node* left;
    Node* right;
    string code;
    
    Node(int f, string n){
        freq=f;
        name=n;
        left=nullptr;
        right=nullptr;
        code="";
    }
};

struct Compare {
    bool operator()(Node* a, Node* b){
        return a->freq > b->freq;
    }
};

void formtree(priority_queue<Node*, vector<Node*>, Compare>& pq) {
    while (pq.size() > 1) {
        Node* node1 = pq.top(); 
        pq.pop();
        Node* node2 = pq.top(); 
        pq.pop();
        Node* node = new Node(node1->freq + node2->freq, node1->name +'@'+ node2->name);
        node->left = node1;
        node->right = node2;
        pq.push(node);
    }
}

void formcode(Node* root, string s) {
    if (!root){
        return;
    }
    if (!root->left && !root->right) {
        root->code = s;
    }
    else {
        formcode(root->left, s + '0');
        formcode(root->right, s + '1');
    }
}

void input(priority_queue<Node*, vector<Node*>, Compare>& pq, vector<Node*>& allnodes) {
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        string name;
        int freq;
        cin >> name >> freq;
        Node* node = new Node(freq, name);
        pq.push(node);
        allnodes.push_back(node);
    }
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        priority_queue<Node*, vector<Node*>, Compare> pq;
        vector<Node*> allnodes;
        
        input(pq, allnodes);
        formtree(pq);
        
        Node* root = pq.top();
        formcode(root, "");
        
        for (auto node : allnodes) {
            cout << node->name << " " << node->code <<" ";
        }
        cout<<endl;
    }
    return 0;
}
