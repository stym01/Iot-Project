#include <iostream>
using namespace std;

// Euclidian Algorithm

int gcd(int n, int m) {
    if (n == 0) 
        return m;
    return gcd(m % n, n);
}

int gcd_iterative(int x,int y)
{
    while (y > 0)
    {
        int temp = x;
        x = y;
        y = temp % y;
    }
    return x;
}

int main() {
    int t;
    cout << "Enter the number of test cases : " ;
    cin >> t;
    while(t--)
    {
        cout << "Enter the value of a and b: ";
        int a, b;
        cin >> a >> b;
        if(a == 0 && b == 0)
        {
            cout << 0;
            continue;
        }
        if(a<0 || b<0)
        {
            cout << -1 ;
            continue;
            
        }
        int ans = gcd(a, b);
        cout << "The GCD of " << a << " and " << b << " is: " << ans << endl;

    }
    return 0;
}


// test cases
// 1. simple  2 5
// 2. multiple of one  6 18
// 3. some calculation litle complex  200 75
// 4. zero case 0 1
// 5. negative -2 4
// 6.  0 0 

// output
// 1. 1
// 2. 6
// 3. 25
// 4. 1
// 5. -1
// 6. 0