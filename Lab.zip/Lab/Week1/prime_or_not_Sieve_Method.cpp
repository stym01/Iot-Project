#include<iostream>
#include<vector>
using namespace std;

void sieveMethod(vector<bool> &isPrime,int n)
{
    for(int p=2;p*p<=n;p++)
    {
        if(isPrime[p] == true)
        {
            for(int i=p*p;i<=n;i += p)
            {
                isPrime[i] = false;
            }
        }
    }
}

int main()
{
    int t;
    cout << "Enter no of test cases : " ;
    cin >> t;
    while(t--)
    {
        int start , end;
        cout << endl;
        cout << "Enter the integers between which you want to find is prime or not : " << endl;
        cin >> start >> end ;
        if(start <0 || end <0)
        {
            cout << "Negative input not allowed" << endl;
            continue;
        }
        if(start >end)
        {
            cout << "Wrong Range" ;
            continue;
        }
        if(start == end)
        {
            for(int i=2;i*i<=start;i++)
            {
                if(start % i == 0){ 
                    cout << start << " is not prime" ;
                    break;
                }
            }
        }
        vector<bool> isPrime (end+1,true);

        sieveMethod(isPrime , end);

        for(int i=start;i<=end;i++)
        {
            if(i == 1) continue;
            if(isPrime[i] == true) 
            {
                cout << i << "  " ;
            }
        }
    }
    return 0;
}

// //Test Cases

// 1. normal  2 10
// 2. bigger 1 50
// 3. start and end with prime 13 107
// 4. reverse the order  5 3 
// 5. equal and prime  13 13 
// 6. equal and not prime  8 8
// 7. negative input

// output 
// 1. 3 5 7
// 2. 2 3 5 7 11 13 17 ....... 43 47 
// 3. 13 17 19 23 29 ......... 89 97 101 103 107
// 4. wrong range
// 5. 13
// 6. nothing
// 7. not allowed