#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

void findIndices(vector<int> &arr , int x)
{
    for(int i=0;i<arr.size();i++)
    {
        for(int j=i;j<arr.size();j++)
        {
            if(arr[i] + arr[j] == x)
            {
                cout << "[" << i << " " << j << "] " ;
            }
        }
    }
}

void optimized(vector<int> &nums ,int target)
{
    vector<pair<int, int>> numWithIndex;
    for (int i = 0; i < nums.size(); i++) {
        numWithIndex.push_back({nums[i], i});
    }

    sort(numWithIndex.begin(), numWithIndex.end());

    int left = 0;
    int right = numWithIndex.size() - 1;
    bool found = false;

    while (left <= right) {
        int sum = numWithIndex[left].first + numWithIndex[right].first;
        if (sum == target) 
        {
            cout <<  numWithIndex[left].second << " " << numWithIndex[right].second << "     ";
            left++;
            right--;
            found = true;
            break;
        }
        else if (sum < target) 
        {
            left++;
        }
        else
        {
            right--;
        }
    }
    if(!found)
    {
        cout << -1 ;
    }
    cout << endl;
}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        int n;
        cin >>n;

        vector<int> arr(n,0);
        for(int i=0;i<n;i++)
        {
            cin >> arr[i];
        }

        int x;
        cin >>x;

        optimized(arr, x);

    }
    return 0;
}



// Test Cases
/*

Input :

9
5
1 2 3 4 5
6
6
1 3 4 2 5 6
7
1
5
5
6
3 3 4 4 5 5
8
5
2 2 2 2 2
4
4
1 2 3 4
10
10
10 20 30 40 50 60 70 80 90 100
150
5
-3 1 4 -2 5
2
6
-5 -3 -2 0 2 5
0


Output :
0 4
0 5
-1
0 5
0 4
-1
4 9
0 4
0 5


*/