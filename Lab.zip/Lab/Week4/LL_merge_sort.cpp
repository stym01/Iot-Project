#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(NULL) {}
};

ListNode* findMiddle(ListNode* head) {
    ListNode* slow = head;
    ListNode* fast = head->next;
    while (fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}

ListNode* mergeLL(ListNode* a, ListNode* b) {
    if (a == NULL) return b;
    if (b == NULL) return a;
    ListNode* head = NULL, * tail = NULL;

    if (a->val <= b->val) {
        head = tail = a;
        a = a->next;
    } else {
        head = tail = b;
        b = b->next;
    }

    while (a != NULL && b != NULL) {
        if (a->val <= b->val) {
            tail->next = a;
            tail = a;
            a = a->next;
        } else {
            tail->next = b;
            tail = b;
            b = b->next;
        }
    }

    if (a == NULL) tail->next = b;
    else tail->next = a;

    return head;
}

ListNode* sortList(ListNode* head) {
    if (head == NULL || head->next == NULL) return head;

    ListNode* middle = findMiddle(head);
    ListNode* right = middle->next;
    middle->next = NULL;
    ListNode* left = head;

    left = sortList(left);
    right = sortList(right);

    return mergeLL(left, right);
}

void printList(ListNode* head) {
    while (head != NULL) {
        cout << head->val << " -> ";
        head = head->next;
    }
    cout << "NULL" << endl;
}

void insertNode(ListNode*& head, int val) {
    if (head == NULL) {
        head = new ListNode(val);
        return;
    }
    ListNode* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = new ListNode(val);
}

int main() {
    ListNode* head = NULL;

    //  5 -> 3 -> 8 -> 1 -> 2
    insertNode(head, 5);
    insertNode(head, 3);
    insertNode(head, 8);
    insertNode(head, 1);
    insertNode(head, 2);

    cout << "Original Linked List: ";
    printList(head);

    head = sortList(head);

    cout << "Sorted Linked List: ";
    printList(head);

    return 0;
}
