#include <iostream>
#include <vector>
using namespace std;

int findIndex(vector<int> &arr, int tar, int n) {
    int start = 0;
    int end = n - 1;
    int mid;

    while (start <= end)
    {
        mid = start + (end - start) / 2;

        if (arr[mid] == tar) return mid;

        if (arr[start] <= arr[mid]) 
        {
            if (tar >= arr[start] && tar < arr[mid]) end = mid - 1;
            else start = mid + 1;
        } 
        else 
        {
            if (tar > arr[mid] && tar <= arr[end]) start = mid + 1;
            else end = mid - 1;
        }
    }
    return -1;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;
        vector<int> arr(n);

        for (int i = 0; i < n; i++) {
            cin >> arr[i];
        }

        int elem;
        cin >> elem; 

        int ansIndex = findIndex(arr, elem, n);
        cout << ansIndex << endl;
        cout << endl ;
    }

    return 0;
}


/*

Test cases
Imput : 

11
8
13 16 20 26 41 2 8 9
20
9
20 26 56 2 8 9 13 16 19
16
9
13 16 19 22 25 62 2 8 11
62
7
234 2 5 8 9 11 30 
2
7
6 14 19 29 36 84 3
29
6
2 6 8 9 12 62
9
2
5 6
6
2
20 6
20
3 
3 5 2
2
3
1 6 9
1
1
9
9

Output :
2
7
5
1
3
3
1
0
2
0
0

*/