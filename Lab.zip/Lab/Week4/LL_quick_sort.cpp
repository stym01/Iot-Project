#include <iostream>
using namespace std;

struct Node {
    int val;
    Node *next;
    Node(int v){
        val=v;
        next=nullptr;
    }
};

Node* partition(Node* head, Node** left, Node** right) {
    Node* pivot = head;
    Node* curr = head->next;
    Node* leftend = nullptr, *rightend = nullptr;
    while (curr) {
        Node* next = curr->next;
        if (curr->val < pivot->val) {
            curr->next = *left;
            *left = curr;
        } else {
            curr->next = *right;
            *right = curr;
        }
        curr = next;
    }
    return pivot;
}

Node* quickSort(Node* head) {
    if (!head || !head->next){
        return head;
    }
    Node *left = nullptr, *right = nullptr;
    Node* pivot = partition(head, &left, &right);
    left = quickSort(left);
    right = quickSort(right);
    Node* tail = left;
    if (!tail) {
        pivot->next = right;
        return pivot;
    }
    while (tail->next){
        tail = tail->next;
    }
    tail->next = pivot;
    pivot->next = right;
    return left;
}

int main() {
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        Node* head = new Node(0);
        Node* root =head;
        for(int i=0;i<n;i++){
            int val;
            cin>>val;
            root->next=new Node(val);
            root=root->next;
        }
        head=head->next;
        
        head = quickSort(head);
        while (head) {
            cout << head->val << " ";
            head = head->next;
        }
    }
    return 0;
}