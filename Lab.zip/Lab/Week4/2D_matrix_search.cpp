#include<iostream>
#include<vector>
using namespace std;

pair<int,int> findElem(vector<vector<int>> & arr , int tar , int n)
{
    int temp = 0;
    int i=0;
    int j=n-1;

    while(temp != tar)
    {
        if(arr[i][j] < tar)
        {
            i++;
        }
        else{
            j--;
        }
        temp = arr[i][j];
    }
    return {i,j};
}

int main()
{
    int t;
    cin >>t;

    while(t--)
    {
        int n;
        cin >>n;

        vector<vector<int>> arr(n , vector<int> ( n,0));
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                cin >> arr[i][j] ;
            }
        }

        int target ;
        cin >> target;

        pair<int,int> ans = findElem(arr , target , n);
        cout << ans.first << " " << ans.second << endl;
    }
    return 0;
}


/*

Test Cases
Input:
1
4
1 2 4 5
3 8 10 13
6 11 12 18
7 14 16 20



*/